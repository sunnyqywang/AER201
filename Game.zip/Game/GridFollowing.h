//
//  GridFollowing.h
//  
//
//  Created by Qingyi Wang on 2015-03-04.
//
//

#ifndef ____GridFollowing__
#define ____GridFollowing__

#include <stdio.h>

void LineFollow(int, int);
void Turning(int);

#endif /* defined(____GridFollowing__) */

