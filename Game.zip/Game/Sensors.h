//
//  Sensors.h
//  
//
//  Created by Qingyi Wang on 2015-03-04.
//
//

#ifndef ____Sensors__
#define ____Sensors__

#include <stdio.h>

void calibrate();
int CheckSensors(bool);

#endif /* defined(____Sensors__) */
