//
//  Arm.h
//  
//
//  Created by Qingyi Wang on 2015-03-24.
//
//

#ifndef ____Arm__
#define ____Arm__

#include <stdio.h>

void LiftArmHalfWay();
void DropArmHalfWay();
void ArmDrop();
void ArmAllTheWay();
void CloseSweeper();
void OpenSweeper();

#endif /* defined(____Arm__) */
