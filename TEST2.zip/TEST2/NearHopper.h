//
//  NearHopper.h
//  
//
//  Created by Qingyi Wang on 2015-03-20.
//
//

#ifndef ____NearHopper__
#define ____NearHopper__

#include <stdio.h>

int ApproachHopper(int, int);
void ExitHopper(int, int, int);

#endif /* defined(____NearHopper__) */
